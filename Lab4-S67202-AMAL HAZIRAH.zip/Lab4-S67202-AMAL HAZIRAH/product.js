// Create object product
var product = {
    productName: "Soap-Sakura",
    quantity: 2,
    price: 25.99
};

// Access and display all properties
document.getElementById("productName").textContent = "Product Name: " + product.productName;
document.getElementById("quantity").textContent = "Quantity: " + product.quantity;
document.getElementById("price").textContent = "Price: $" + product.price.toFixed(2);
