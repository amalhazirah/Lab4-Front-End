var textField = document.getElementById("myTextField");

textField.onchange = function() {
    this.style.border = "2px solid blue";
};

textField.onfocus = function() {
    this.style.backgroundColor = "#f0f0f0";
};

textField.onblur = function() {
    this.style.backgroundColor = "#ffffff";
};
