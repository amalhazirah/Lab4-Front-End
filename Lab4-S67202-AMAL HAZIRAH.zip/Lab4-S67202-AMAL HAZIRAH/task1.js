// Function to find the square of a given number
function findSquare(number) {
    return number * number;
}

// Function to find the sum of cubes of two numbers
function sumOfCubes(num1, num2) {
    return Math.pow(num1, 3) + Math.pow(num2, 3);
}

// Function to reverse a number
function reverseNumber(number) {
    let reversed = 0;
    while (number > 0) {
        reversed = (reversed * 10) + (number % 10);
        number = Math.floor(number / 10);
    }
    return reversed;
}

// Function to print all numbers between 1 and 100 which is divisible by a given number z
function printDivisibleNumbers(z) {
    let output = '';
    for (let i = 1; i <= 100; i++) {
        if (i % z === 0) {
            output += i + ', ';
        }
    }
    return output.slice(0, -2); // Remove the last comma and space
}

// Output results
document.getElementById('output1').innerHTML = 'Square of 5: ' + findSquare(5);
document.getElementById('output2').innerHTML = 'Sum of cubes of 2 and 3: ' + sumOfCubes(2, 3);
document.getElementById('output3').innerHTML = 'Reverse of 12345: ' + reverseNumber(12345);
document.getElementById('output4').innerHTML = 'Numbers between 1 and 100 divisible by 5: ' + printDivisibleNumbers(5);
