// Define Parent object employee
function Employee(employeeName, employeeId, salary) {
    this.employeeName = employeeName;
    this.employeeId = employeeId;
    this.salary = salary;
}

// Define Child object Manager
function Manager(employeeName, employeeId, salary, managerName, branch) {
    Employee.call(this, employeeName, employeeId, salary);
    this.managerName = managerName;
    this.branch = branch;
}

// Inherit properties of Employee
Manager.prototype = Object.create(Employee.prototype);
Manager.prototype.constructor = Manager;

// Create an instance of the Manager object
var manager = new Manager("Jasmin Hamid", "DD00321", 50000, "Syafiq Kyle", "Perlis");

// Display all properties
document.getElementById("employeeName").textContent = "Employee Name: " + manager.employeeName;
document.getElementById("employeeId").textContent = "Employee ID: " + manager.employeeId;
document.getElementById("salary").textContent = "Salary: $" + manager.salary.toFixed(2);
document.getElementById("managerName").textContent = "Manager Name: " + manager.managerName;
document.getElementById("branch").textContent = "Branch: " + manager.branch;
