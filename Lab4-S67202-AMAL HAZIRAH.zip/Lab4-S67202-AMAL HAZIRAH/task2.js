// Function to find sum of digits of a number using recursion
function sumOfDigits(number) {
    // Base case: if number is a single digit, return it
    if (number < 10) {
        return number;
    }
    // Recursive case: sum the last digit with sumOfDigits of the remaining digits
    else {
        return number % 10 + sumOfDigits(Math.floor(number / 10));
    }
}

// Function to compute x raised to the power y using recursion
function power(x, y) {
    // Base case: if exponent is 0, return 1
    if (y === 0) {
        return 1;
    }
    // Recursive case: compute x^(y-1) and multiply by x
    else {
        return x * power(x, y - 1);
    }
}

// Function to calculate the sum of digits when the button is clicked
function calculateSumOfDigits() {
    const number = parseInt(document.getElementById('number').value);
    if (!isNaN(number)) {
        document.getElementById('output1').innerHTML = 'Sum of digits of ' + number + ': ' + sumOfDigits(number);
    } else {
        document.getElementById('output1').innerHTML = 'Please enter a valid number';
    }
}

// Function to calculate the power when the button is clicked
function calculatePower() {
    const x = parseInt(prompt('Enter the base number:'));
    const y = parseInt(prompt('Enter the exponent:'));
    if (!isNaN(x) && !isNaN(y)) {
        document.getElementById('output2').innerHTML = x + ' raised to the power ' + y + ': ' + power(x, y);
    } else {
        document.getElementById('output2').innerHTML = 'Please enter valid numbers';
    }
}
