// Add a new row to the table
function addRow(name, email, phone) {
    var table = document.getElementById("myTable").getElementsByTagName('tbody')[0];
    var newRow = table.insertRow();

    // Insert cells into the new row
    var cell1 = newRow.insertCell(0);
    var cell2 = newRow.insertCell(1);
    var cell3 = newRow.insertCell(2);
    var cell4 = newRow.insertCell(3);

    // Add data to the cells
    cell1.innerHTML = table.rows.length;
    cell2.innerHTML = name;
    cell3.innerHTML = email;
    cell4.innerHTML = phone;
}

// Add new record
addRow("Mukhriz Jamil Asoka", "mukriz@corp.jo", "651181187223");

// Add table header
var table = document.getElementById("myTable");
var header = table.createTHead();
var row = header.insertRow(0);
var headers = ["#", "Name", "Email", "Phone"];
for (var i = 0; i < headers.length; i++) {
    var cell = row.insertCell(i);
    cell.innerHTML = headers[i];
}

// Delete row when clicked
var rows = document.querySelectorAll("#myTable tbody tr");
rows.forEach(function(row) {
    row.addEventListener("click", function() {
        this.remove();
    });
});
