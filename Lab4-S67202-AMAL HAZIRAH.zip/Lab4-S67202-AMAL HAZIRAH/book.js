// Define the constructor function for the Book object
function Book(bookName, authorName) {
    this.bookName = bookName;
    this.authorName = authorName;
}

// Add prototype property price to Book object
Book.prototype.price = 0;

// Create an instance of the Book object
var book = new Book("Isteri Tuan Madey", "Siti Amal");

// Set the price of the book
book.price = 29.99;

// Display all properties
document.getElementById("bookName").textContent = "Book Name: " + book.bookName;
document.getElementById("authorName").textContent = "Author Name: " + book.authorName;
document.getElementById("price").textContent = "Price: $" + book.price.toFixed(2);
